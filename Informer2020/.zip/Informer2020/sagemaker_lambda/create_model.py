import json
import boto3


def lambda_handler(event, context):
    """
    모델 레지스트리에서 최신 버전의 모델 승인 상태를 변경하는 람다 함수.
    """
    
    try:
        sm_client = boto3.client("sagemaker")

        ##############################################
        # 람다 함수는 Event Bridge의 패턴 정보를 event 개체를 통해서 받습니다.
        ##############################################   
        
        model_package_group_name = event["model_package_group_name"]
        print("model_package_group_name: \n", model_package_group_name)      

        
        approved_model = sm.list_model_packages(
            ModelPackageGroupName=model_package_group_name,
            ModelApprovalStatus='Approved',
            SortBy='Name',
            SortOrder='Descending'
        )
        
        # 패키지에 대한 모델 가져옵니다.
        container_list = [
            {
                "ModelPackageName": approved_model['ModelPackageSummaryList'][0]['ModelPackageArn'], 
                "Environment": {"SAGEMAKER_PROGRAM": "predictor.py"}
            }
        ]

        try:
            sm.delete_model(ModelName=model_package_group_name)
        except:
            pass

        create_model_response = sm.create_model(
            ModelName=model_package_group_name,
            ExecutionRoleArn=role,
            Containers=container_list
        )
        print("Model arn : {}".format(create_model_response["ModelArn"]))

        return_msg = f"Success"
        
        ##############################################        
        # 람다 함수의 리턴 정보를 구성하고 리턴 합니다.
        ##############################################        

        return {
            "statusCode": 200,
            "body": json.dumps(return_msg),
            "other_key": "example_value",
        }

    except BaseException as error:
        return_msg = f"There is no model_package_group_name{model_package_group_name}"                
        error_msg = f"An exception occurred: {error}"
        print(error_msg)    
        return {
            "statusCode": 500,
            "body": json.dumps(return_msg),
            "other_key": "example_value",
        }        
        

